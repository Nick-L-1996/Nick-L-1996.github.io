#include "Fan_Control.h"
#include "Arduino.h"



void Fan_Control::AllFansOn(){
  digitalWrite(RFan,HIGH);
  digitalWrite(LFan,HIGH);

}

void Fan_Control::AllFansOff(){
  digitalWrite(RFan,LOW);
  digitalWrite(LFan,LOW);
 
}

//puts on two diagonal fans, switching the two that are on periodicially
//use if need less airflow than full power
void Fan_Control::alternateFans(){
  altFanCount++;
  if(altFanCount>20000){
    if(altFanSwitch == true){
      digitalWrite(RFan,HIGH);
       digitalWrite(LFan,LOW);
      
       altFanSwitch = false;
    }
    else{
        digitalWrite(RFan,LOW);
        digitalWrite(LFan,HIGH);
      
       altFanSwitch = true;
    }
    altFanCount=0;
  }
}

