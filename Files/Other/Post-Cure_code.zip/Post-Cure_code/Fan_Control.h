
#ifndef FAN_CONTROL_H_
#define FAN_CONTROL_H_

class Fan_Control{
 public:
  char RFan = 4;
  char LFan = 3;
  int altFanCount = 0;
  bool altFanSwitch = true;



  void AllFansOn();
  void AllFansOff();
  void alternateFans();
};



#endif
