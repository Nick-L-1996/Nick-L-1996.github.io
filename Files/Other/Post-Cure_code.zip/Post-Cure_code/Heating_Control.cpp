#include "Heating_Control.h"
#include <TimerOne.h>



//create a function that makes a 1/12Hz square wave with a given duty cycle

void Heating_Control::StartTimer() {
  Timer1.initialize(20000);
  Timer1.attachInterrupt(CreateWave);
  Timer1.start();
  pinMode(10, OUTPUT);

}
void Heating_Control::CreateWave() {
  if (ElementOn) {
    // Serial.println("Interrupt");
    WaveHigh = !WaveHigh;
    //Sets duty cycle into a range of 0-100
    if (dutyCycle < 0) {
      dutyCycle = 0;
    }
    else if (dutyCycle > 100) {
      dutyCycle = 100;
    }
    if (dutyCycle == 100) {
      digitalWrite(HeatingElementPin, HIGH);
    }
    else if (dutyCycle == 0) {
      digitalWrite(HeatingElementPin, LOW);
    }
    else {

      if (WaveHigh == true) {
        digitalWrite(HeatingElementPin, HIGH);
        Timer1.setPeriod(dutyCycle * 120000L);
        // Serial.println("High");
      }
      else if (WaveHigh == false) {
        digitalWrite(HeatingElementPin, LOW);
        Timer1.setPeriod(12000000 - (dutyCycle * 120000L));
        // Serial.println("LOW");
      }
    }
  }
  else {
    digitalWrite(HeatingElementPin, LOW);
  }
}
bool Heating_Control::HeatChamber() {
  if (desiredTemp >= GetChamberTemp()) {
    if (GetChamberTemp() < 30) {
      dutyCycle = 10;
    }
    else if (GetChamberTemp() < 35) {
      dutyCycle = 15;
    }
    else if (GetChamberTemp() < 40) {
      dutyCycle = 20;
    }
    else if (GetChamberTemp() < 45) {
      dutyCycle = 25;
    }
    else if (GetChamberTemp() < 50) {
      dutyCycle = 30;
    }
    else if (GetChamberTemp() < 55) {
      dutyCycle = 35;
    }
    else if (GetChamberTemp() < 60) {
      dutyCycle = 40;
    }
    else if (GetChamberTemp() < 65) {
      dutyCycle = 45;
    }
    else if (GetChamberTemp() < 70) {
      dutyCycle = 50;
    }
    if (GetChamberTemp() == desiredTemp) {
      return true;
    }
    else {
      return false;
    }
  }
  else {
    dutyCycle = 0;
    return true;
  }
}
void Heating_Control::RunFan() {
  if (ElementOn) {
    digitalWrite(HeatingElementFan, HIGH);
  }
  else if (GetChamberTemp() > 30) {
    digitalWrite(HeatingElementFan, HIGH);
  }
  else {
    digitalWrite(HeatingElementFan, LOW);
  }

}

int Heating_Control::GetChamberTemp() {
  int avgTemp = (analogRead(UpperThermistor) + analogRead(LowerThermistor)) / 2;
  return (26 + ((avgTemp - 185) / 12));
}

