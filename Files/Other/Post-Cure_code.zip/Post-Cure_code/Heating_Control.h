
#ifndef HEATING_CONTROL_H_
#define HEATING_CONTROL_H_
#define UpperTherm A0;
#define LowerTherm A1;
//this controls the heating element, heating element fan and is what reads the thermistors
class Heating_Control{
  public:

static bool WaveHigh;
static long dutyCycle;
static bool ElementOn;
#define HeatingElementPin 10
#define HeatingElementFan 11
#define UpperThermistor A0
#define LowerThermistor A1
int desiredTemp = 0;

void StartTimer();
static void CreateWave();
bool HeatChamber();
void RunFan();
int GetChamberTemp();

};
#endif
