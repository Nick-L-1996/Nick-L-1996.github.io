#include "LCDScreenControl.h"
#include <Wire.h>
#include <LiquidCrystal_I2C.h>
#include "Arduino.h"

LiquidCrystal_I2C lcd(0x3F, 20, 4); // set the LCD address to 0x3F for a 20 chars and 4 line display

void LCDScreenControl::init()
{
  lcd.init();                      // initialize the lcd
  lcd.backlight();
}

void LCDScreenControl::Clear() {
  lcd.clear();
}


void LCDScreenControl::PrintStartUpScreen() {
  lcd.clear();
  lcd.setCursor(7, 0);
  lcd.print("Press");
  lcd.setCursor(4, 1);
  lcd.print("Start/Pause");
  lcd.setCursor(6, 2);
  lcd.print("To Begin");
}

void LCDScreenControl::PrintInputScreenOne() {
  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print("Select Time & Temp");
  lcd.setCursor(0, 1);
  lcd.print("Temperature -->");
  lcd.setCursor(0, 2);
  lcd.print("Time -->");
}
void LCDScreenControl::PrintInputScreenTwo() {
  if (timeTrack == 0) {
    timeTrack = millis();
    lcd.setCursor(0, 3);
    lcd.print("Press Start/Pause to");
  }
  else if (millis() - timeTrack > 700) {
    timeTrack = millis();
    if (scrollState > 6) {
      scrollState = 0;
    }
    else {
      scrollState++;
    }
    switch (scrollState) {
      case 0:
        lcd.setCursor(0, 3);
        lcd.print("Press Start/Pause to");
        break;

      case 1:
        lcd.setCursor(0, 3);
        lcd.print("ress Start/Pause to ");
        break;
      case 2:
        lcd.setCursor(0, 3);
        lcd.print("ess Start/Pause to s");
        break;

      case 3:
        lcd.setCursor(0, 3);
        lcd.print("ss Start/Pause to st");
        break;

      case 4:
        lcd.setCursor(0, 3);
        lcd.print("s Start/Pause to sta");
        break;

      case 5:
        lcd.setCursor(0, 3);
        lcd.print(" Start/Pause to star");
        break;
      case 6:
        lcd.setCursor(0, 3);
        lcd.print("Start/Pause to start");
        break;
    }
  }

}

void LCDScreenControl::PrintInputTempTime(int Temp, int Time) {
  lcd.setCursor(16, 1);
  lcd.print(Temp);
  lcd.setCursor(19, 1);
  lcd.print("C");
  lcd.setCursor(13, 2);
  lcd.print("   ");
  lcd.setCursor(13,2);
  lcd.print(Time);
  lcd.setCursor(17, 2);
  lcd.print("min");
}
void LCDScreenControl::PrintWarmUpScreen() {
  lcd.clear();
  lcd.setCursor(5, 1);
  lcd.print("Warming Up");

}
void LCDScreenControl::PrintWarmUpTemp(int temp) {
  if (lastTemp != temp) {
    lcd.setCursor(9, 2);
    lcd.print(temp);
    lcd.setCursor(11, 2);
    lcd.print("C");
  }

}
void LCDScreenControl::PrintWarmedUpScreen() {
  lcd.clear();
  lcd.setCursor(5, 0);
  lcd.print("Warmed Up");
  lcd.setCursor(1, 2);
  lcd.print("Place print inside");
  lcd.setCursor(1, 3);
  lcd.print("and shut the door");
}
void LCDScreenControl::PrintWarmedUpTemp(int temp) {
  if (lastTemp != temp) {
    lcd.setCursor(9, 1);
    lcd.print(temp);
    lcd.setCursor(11, 1);
    lcd.print("C");
  }
}
void LCDScreenControl::PrintCureScreen() {
  lcd.clear();
  lcd.setCursor(7, 0);
  lcd.print("Curing");
  lcd.setCursor(1, 1);
  lcd.print("Time Left     Temp");
}
void LCDScreenControl::PrintCureTimeandTemp(long Time, int temp) {
  int hour;
  int minute;
  int sec;
  hour = Time / 3600000L;
  long temp1 = Time - ((long)hour * 3600000);
  minute = temp1 / 60000L;
  long temp2 = temp1 - ((long)minute * 60000);
  sec = temp2 / 1000L;
  

  if (!((LastHour == hour) && (LastMinute == minute) && (LastSecond == sec))) {
    Serial.println("Writting Time");
    lcd.setCursor(1, 2);
    if (hour < 10) {
      lcd.print(0);
      lcd.setCursor(2, 2);
      lcd.print(hour);
    }
    else {
      lcd.print(hour);
    }
    lcd.setCursor(3, 2);
    lcd.print(":");
    lcd.setCursor(4, 2);
    if (minute < 10) {
      lcd.print(0);
      lcd.setCursor(5, 2);
      lcd.print(minute);
    }
    else {
      lcd.print(minute);
    }
    lcd.setCursor(6, 2);
    lcd.print(":");
    lcd.setCursor(7, 2);
    if (sec < 10) {
      lcd.print(0);
      lcd.setCursor(8, 2);
      lcd.print(sec);
    }
    else {
      lcd.print(sec);
    }
    LastHour = hour;
    LastMinute = minute;
    LastSecond = sec;
  }
  if (temp != lastTemp) {
    lcd.setCursor(16, 2);
    lcd.print(temp);
  }
}

void LCDScreenControl::PrintCureDone(){
  lcd.clear();
  lcd.setCursor(5,0);
  lcd.print("Curing Done");
  lcd.setCursor(3,1);
  lcd.print("Please Remove");
  lcd.setCursor(0,2);
  lcd.print("Your Print and Press");
  lcd.setCursor(1,3);
  lcd.print("Start/Pause to End");
}

void LCDScreenControl::PrintPaused(){
  lcd.setCursor(4,0);
  lcd.print("Curing Paused");
}

