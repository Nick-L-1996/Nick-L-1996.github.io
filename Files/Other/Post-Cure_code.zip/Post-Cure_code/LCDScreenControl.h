#ifndef LCDSCREENCONTROL_H_
#define LCDSCREENCONTROL_H_
class LCDScreenControl {
    long timeTrack = 0;
    int scrollState = 0;
    int lastTemp = 0;
    int LastHour = 0;
    int LastMinute = 0;
    int LastSecond = 0;
  public:
    void init();
    void Clear();
    void PrintStartUpScreen();
    void PrintInputScreenOne();
    void PrintInputScreenTwo();
    void PrintInputTempTime(int Temp, int Time);
    void PrintWarmUpScreen();
    void PrintWarmUpTemp(int temp);
    void PrintWarmedUpScreen();
    void PrintWarmedUpTemp(int temp);
    void PrintCureScreen();
    void PrintCureTimeandTemp(long Time, int temp);
    void PrintCureDone();
    void PrintPaused();
};
#endif
