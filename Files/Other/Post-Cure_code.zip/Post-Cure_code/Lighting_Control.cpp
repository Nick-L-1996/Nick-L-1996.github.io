#include "Lighting_Control.h" 
#include "Arduino.h"

void Lighting_Control::TurnOnLEDs(){
  digitalWrite(LEDPin, HIGH);
}

void Lighting_Control::TurnOffLEDs(){
  digitalWrite(LEDPin, LOW);
  
}

