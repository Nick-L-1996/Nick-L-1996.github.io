#ifndef LIGHTING_CONTROL_H_
#define LIGHTING_CONTROL_H_

class Lighting_Control{
  char LEDPin = 9;
  void TurnOnLEDs();
  void TurnOffLEDs();
};

#endif

