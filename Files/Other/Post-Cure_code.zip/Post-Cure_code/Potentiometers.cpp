#include "Potentiometers.h"
#include "Arduino.h"

int Potentiometers::GetTemp(){
  //Temperature select goes from 30C to 70C
  return (30+(analogRead(TempKnob)/25));
}
long Potentiometers::GetTime(){
  return (analogRead(TimeKnob)*14076L);
}

