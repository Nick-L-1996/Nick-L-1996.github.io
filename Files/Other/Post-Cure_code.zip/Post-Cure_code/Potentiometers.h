#ifndef POTENTIOMETERS_H_
#define POTENTIOMETERS_H_
#define TempKnob A2
#define TimeKnob A3
class Potentiometers {
  public:
  int GetTemp();
  long GetTime();
};
#endif
