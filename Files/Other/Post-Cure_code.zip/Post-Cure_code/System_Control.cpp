#include "System_Control.h"
#include "Timer_Control.h"
#include "LCDScreenControl.h"
#include "Arduino.h"
#include "Heating_Control.h"
#include "Fan_Control.h"
#include "Potentiometers.h"

Timer_Control TC;
LCDScreenControl LCDControl;
Heating_Control HC;
Fan_Control FC;
Potentiometers P;



bool Heating_Control::WaveHigh = true;
long Heating_Control::dutyCycle = 50;
bool Heating_Control::ElementOn = false;
long InputTime = 0;
int InputTemp = 0;

void System_Control::InitializeSystem() {
  pinMode(7, INPUT_PULLUP);
  pinMode(2, INPUT);
  pinMode(12, OUTPUT);
  pinMode(4, OUTPUT);
  pinMode(3, OUTPUT);
  digitalWrite(3, LOW);
  digitalWrite(4, LOW);
  digitalWrite(12, LOW);
  HC.StartTimer();
  LCDControl.init();
}
void System_Control::RunSystem() {
  HC.RunFan();//runs heating element fan
 
  switch (CureState) {
    case StartScreen:
      if (printedScreen == false) {
        LCDControl.PrintStartUpScreen();
        printedScreen = true;
        Serial.print("Printed Intro");
      }
      if (digitalRead(7) == 0) {
        CureState = InputScreen;
        printedScreen = false;
        buttonReleased = false;
      }
      break;

    case InputScreen:
      if (printedScreen == false) {
        LCDControl.PrintInputScreenOne();
        printedScreen = true;
      }
      LCDControl.PrintInputScreenTwo();
      LCDControl.PrintInputTempTime(P.GetTemp(), (int)(P.GetTime() / (60000L)));
      if (digitalRead(7) == 1) {
        buttonReleased = true;
      }
      if ((digitalRead(7) == 0) && (buttonReleased == true)) {
        CureState = WarmUpSequence;
        InputTime = ((P.GetTime()/60000L)*60000L); //rounds to nearest minute
        InputTemp = P.GetTemp();
        printedScreen = false;
        buttonReleased = false;
      }

      break;

    case WarmUpSequence:
      HC.ElementOn = true;
      FC.AllFansOn();
      HC.desiredTemp = InputTemp;
      if (printedScreen == false) {
        LCDControl.PrintWarmUpScreen();
        printedScreen = true;
      }
      LCDControl.PrintWarmUpTemp(HC.GetChamberTemp());
      //gradually heat up chamber
      delay(100);//temp delay
      if(HC.HeatChamber()){
        CureState = WarmedUp;
      }
      printedScreen = false;
      break;

    case WarmedUp:
      
      if (printedScreen == false) {
        LCDControl.PrintWarmedUpScreen();
        printedScreen = true;
      }
      if (digitalRead(2) == 1) {
        doorIsClosed = true;
      }
      else {
        doorIsClosed = false;
        doorWasOpen = true;
        digitalWrite(12, HIGH);
      }
      if (doorIsClosed && doorWasOpen) {
        doorWasOpen = false;
        printedScreen = false;
        CureState = CureSequence;
        TC.InitializeTimer(InputTime);
      }

      LCDControl.PrintWarmedUpTemp(HC.GetChamberTemp());
      HC.HeatChamber();
      break;

    case CureSequence:
      //display time
      //turn on LEDs, keep chamber warm
      HC.HeatChamber();
      if (printedScreen == false) {
        LCDControl.PrintCureScreen();
        printedScreen = true;
        digitalWrite(12, HIGH);
      }
      LCDControl.PrintCureTimeandTemp(TC.CureTime - TC.TimeElapsed, HC.GetChamberTemp());
      if (TC.RunTimer(0) == true) {
        CureState = CureDone;
        printedScreen = false;
      }
      break;

    case CureDone:
      HC.ElementOn = false;
      if (printedScreen == false) {
        LCDControl.PrintCureDone();
        printedScreen = true;
        FC.AllFansOff();
        digitalWrite(12, LOW);
      }


      if (digitalRead(7) == 0) {
        printedScreen = false;
        CureState = StartScreen;
        delay(1000);
      }
      //turn of LEDs stop warming chamber. Wait for door to be opened and then closed.
      break;

    case Pause:
      if (printedPauseScreen == false) {
        LCDControl.PrintPaused();
      }
      digitalWrite(12, LOW);
      //say the system is paused, turn off the LEDs, keep chamber warm (unless the air is too hot)
      TC.UpdateTimerPaused();
      if (digitalRead(7) == 0) {
        digitalWrite(12, HIGH);
        delay(50);
        if (digitalRead(2) == 1) {
          printedPauseScreen = false;
          CureState = CureSequence;
          LCDControl.PrintCureScreen();
        }
      }
      break;
  }
}



