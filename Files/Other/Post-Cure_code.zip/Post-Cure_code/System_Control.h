#ifndef SYSTEM_CONTROL_H_
#define SYSTEM_CONTROL_H_

class System_Control{
    public:
  //Variable that holds all possible States for the State Machine
   enum CureStates {
    StartScreen,
    InputScreen,
    WarmUpSequence,
    WarmedUp,
    CureSequence,
    CureDone,
    Pause
  } CureState = StartScreen; 

//flags
  bool printedScreen = false;
  bool printedPauseScreen = false;

  bool buttonReleased = true;
  bool doorWasOpen = false;
  bool doorIsClosed = false;

void RunSystem();
void InitializeSystem();

  
};
#endif
