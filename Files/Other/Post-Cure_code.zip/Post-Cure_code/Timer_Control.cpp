#include "Arduino.h"
#include "Timer_Control.h"

void Timer_Control::InitializeTimer(unsigned long CTime){
  CureTime=CTime;
  TimeElapsed=0;
  LastTime=millis();
  
}
void Timer_Control::UpdateTimer(){
  unsigned long now = millis();
  TimeElapsed+=now-LastTime;
  LastTime=now; 
  
}

void Timer_Control::UpdateTimerPaused(){
  LastTime=millis();
}


bool Timer_Control::TimeUp(){
  if(TimeElapsed>=CureTime){
    return true;
  }
  else{
    return false;
    }
  }


bool Timer_Control::RunTimer(int Paused){

  switch(Paused){
    case 0:
    UpdateTimer();
    break;
    case 1:
    UpdateTimerPaused();
    break;
  }
  if(TimeUp()){
    return true;
  }
  else{
    return false;
    } 
}

