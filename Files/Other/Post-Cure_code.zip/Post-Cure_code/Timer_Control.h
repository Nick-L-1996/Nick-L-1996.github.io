#ifndef TIMER_CONTROL_H_
#define TIMER_CONTROL_H_

class Timer_Control{
 
public:
  void InitializeTimer(unsigned long CTime);
  void UpdateTimer();
  void UpdateTimerPaused();
  bool TimeUp();
  bool RunTimer(int CureState);
  unsigned long CureTime = 0;
  unsigned long LastTime=0;
  unsigned long TimeElapsed=0;
  
};



#endif
